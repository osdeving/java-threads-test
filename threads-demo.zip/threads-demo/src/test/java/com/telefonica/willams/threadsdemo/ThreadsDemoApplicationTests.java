package com.telefonica.willams.threadsdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ThreadsDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
