package com.telefonica.willams.threadsdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ThreadsDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ThreadsDemoApplication.class, args);
	}

}
